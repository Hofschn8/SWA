﻿using DoJo1_Stack.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoJo1_Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStack<int> myStack = new MyStack<int>();

            myStack.remove();
            myStack.peek();

            myStack.push(1);
            myStack.push(2);
            myStack.push(3);
            myStack.peek();
            myStack.showFullStack();

            myStack.remove();
            myStack.showFullStack();
            myStack.peek();
            myStack.remove();
            myStack.remove();
            myStack.showFullStack();
            myStack.remove();
            myStack.push(10);
            myStack.push(9);
            myStack.push(7);
            myStack.remove();
            myStack.push(8);
            myStack.peek();
            myStack.showFullStack();

            Console.ReadKey();

            MyStack<string> MyStringStack = new MyStack<string>();
            MyStringStack.push("!");
            MyStringStack.push("World ");
            MyStringStack.push("Hello ");
            MyStringStack.showFullStack();
            Console.ReadKey();




        }
    }
}
