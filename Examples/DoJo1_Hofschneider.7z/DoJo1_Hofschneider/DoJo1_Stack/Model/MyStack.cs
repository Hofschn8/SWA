﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoJo1_Stack.Model
{
    public class MyStack<T>
    {
        //Nested Class
        public class Node
        {
            private T element;
            public T Element { get { return element; } set { if (value != null) element = value; } }

            //verweist auf den Next node
            private Node nextNode;
            public Node NextNode { get { return nextNode; } set { if (value != null) nextNode = value; } }

            // aus dem T Element wird ein Node generiert
            public Node(T Element)
            {
                if (Element != null)
                {
                    this.Element = Element;
                }
            }
        }

        // hält eine Referenz auf das oberste Element des Stacks
        private Node topElement;
        public Node TopElement { get { return topElement; } set { topElement = value; } }

        public void push(T element)
        {
            if (element != null)
            {
                // wenn Stack noch leer, dann wird nur das neue Element zum TopElement
                if (this.TopElement == null)
                {
                    this.TopElement = new Node(element);
                }
                // wenn Stack nicht mehr leer, dann muss das bishere TopElement geändert werden 
                else
                {
                    Node n = new Node(element);
                    n.NextNode = this.TopElement;
                    this.TopElement = n;
                }
                Console.WriteLine("Element \"" + element.ToString() + "\" added!");
            }
        }


        public void remove()
        {
            if (TopElement == null)
            {
                Console.WriteLine("Stack empty!");
            }
            // das 2.Element vom Stack wird zum TopElement
            else
            {
                Console.WriteLine("Element \"" + this.TopElement.Element.ToString() + "\" removed!");
                this.TopElement = this.TopElement.NextNode;
            }
        }

        public void peek()
        {
            if (this.TopElement != null)
            {
                Console.WriteLine("PeekElement: \"" + this.TopElement.Element.ToString() + "\"");
            }
            else
            {
                Console.WriteLine("Stack empty!");
            }



        }

        public void showFullStack()
        {
            Console.WriteLine("-- Full Stack --");
            for (Node n = this.TopElement; n != null; n = n.NextNode)
            {
                Console.Write(n.Element.ToString() + "- ");
            }
            Console.WriteLine("");

        }


    }






}

